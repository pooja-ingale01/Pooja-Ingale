# Simple-HTML-Page
This is the simple HTML page which contain a table with four column- ID, Name, Mobile and Email ID. One can Add or Delete the rows dynamically.
